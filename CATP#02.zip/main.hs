addMe :: Integer -> Integer -> Integer
addMe x y = x + y

invertelst :: [Integer] -> [Integer]
invertelst [] = []
invertelst (h:t) = invertelst(t) ++ [h]


potencia x 0 = 1
potencia x 1 = x
potencia x y = x*potencia x (y-1)


powlist [] y = []
powlist (h:t) y = [potencia h y] ++ powlist t y

somatorio [] = 0
somatorio (h:t) = foldl (+) h t

norma [] = 0
norma (h:t) = sqrt(foldl (+) (potencia h 2) (powlist t 2))



main :: IO ()
main = print(norma [0.1, 0.2, 0.3, 0.4])